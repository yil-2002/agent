# O'zgarishlar hisoboti — 1+2 bosqich (parol/sessiya auth + xavfsizlik)

## Yangi fayllar (6)
- `bot/handlers/auth.py` — /logout, /sessions, /change_password
- `bot/handlers/confirm.py` — destruktiv amallar uchun yagona confirm callback
- `bot/models/session.py` — Session modeli (User/UserRole o'rniga)
- `bot/services/auth_service.py` — parol hash/tekshirish, lockout, sessiya logikasi
- `scripts/gen_password_hash.py` — BOT_PASSWORD_HASH generatsiya qilish skripti
- `scripts/__init__.py`

## O'chirilgan fayllar (2)
- `bot/handlers/admin.py` — rol-asosli approve/reject/promote/ban (kerak emas)
- `bot/models/user.py` — UserRole/User (Session bilan almashtirildi)

## O'zgartirilgan fayllar (35) — muhimlik bo'yicha

### FATAL buglar (bot umuman ishga tushmasdi yoki asosiy funksiyalar crash bo'lardi)
1. `bot/constants.py` — `ButtonText.FILTER_ERROR` mavjud bo'lmagan `Emoji.LEVEL_ERROR`ga
   murojaat qilardi (AttributeError import vaqtida).
2. `bot/constants.py` — `Emoji.ROLES` hali e'lon qilinmagan `ADMIN`/`SUPERADMIN`ga
   murojaat qilardi (NameError import vaqtida).
3. `bot/constants.py` — `Emoji.FOLDER`/`Emoji.FILE` umuman yo'q edi (`/files` crash).
4. `bot/constants.py` — `ButtonText.NETWORK` umuman yo'q edi (monitoring menyusi crash).
5. `bot/utils/__init__.py` — `truncate_text`/`format_status_emoji` yozilgan-u,
   export qilinmagan edi → docker.py, ai_coding.py, logs.py, monitoring.py
   import qilinganda ImportError berardi.

### Xavfsizlik teshiklari
6. `bot/handlers/file_manager.py` — path traversal: callback_data orqali
   arbitrary file read, upload orqali arbitrary file write. `validate_path()`
   endi majburiy chaqiriladi, fayl nomi sanitize qilinadi.
7. `docker/docker-compose.yml` — `privileged: true` va keraksiz `/home:ro`
   mounti olib tashlandi.
8. Global auth gate (`bot/middlewares/auth.py`, `bot/main.py`) — endi
   HAR BIR update auth tekshiruvidan o'tadi (avval faqat /start tekshirilardi,
   qolgan barcha buyruqlar himoyasiz edi).

### Funksional buglar
9. `bot/utils/decorators.py` — confirm_destructive callback_data formati
   `keyboards/inline.py`dagi format bilan mos kelmasdi va hech qanday
   CallbackQueryHandler ro'yxatdan o'tkazilmagandi → reboot/shutdown tugmasi
   ishlamas edi. Endi markazlashgan CONFIRM_REGISTRY + bitta global handler.
10. `bot/handlers/docker.py`, `bot/handlers/backup.py` — endi mavjud bo'lmagan
    `get_confirmation_keyboard`ni import qilardi (dead import → ImportError).
11. `bot/handlers/ai_coding.py`, `bot/handlers/vpn.py` — fayl oxiridagi
    tartibsiz importlar boshiga ko'chirildi.
12. `bot/middlewares/rate_limit.py` — endi module-level singleton
    (`rate_limiter`), auth gate ichida chaqiriladi (avval umuman ulanmagan
    va har chaqiriqda instance qayta yaratilib holat yo'qolardi).
13. `db.log_command(...)` — endi `@log_execution` dekoratori orqali deyarli
    barcha buyruqlarda chaqiriladi (avval jadval doim bo'sh edi).

### Arxitektura o'zgarishi (rol tizimidan parolga o'tish)
14. `bot/config.py` — `ALLOWED_USER_IDS` olib tashlandi, `BOT_PASSWORD_HASH`,
    `SESSION_TTL_DAYS`, `MAX_LOGIN_ATTEMPTS`, `LOGIN_LOCKOUT_MINUTES` qo'shildi.
15. `bot/database.py` — `users` jadvali/CRUD o'rniga `sessions` va
    `login_attempts` jadvallari/CRUD.
16. `bot/handlers/start.py` — eski `AuthMiddleware.check_user` chaqiruvi olib
    tashlandi (endi global gate orqali).

## Tekshiruv (barchasi shu ishchi muhitda bajarildi va o'tdi)
- Har bir `.py` fayl uchun `py_compile` orqali sintaksis tekshiruvi.
- `Emoji`/`Messages`/`ButtonText` sinflarining har bir murojaati haqiqatan
  mavjudligi statik tekshirildi.
- Har bir `db.<method>()` chaqiruvi `Database` klassidagi metodlar bilan
  solishtirildi.
- Har bir `settings.<attr>` chaqiruvi `Settings` klassidagi maydonlar bilan
  solishtirildi.
- Har bir `from bot.X import Y` — Y nomi X modulida haqiqatan mavjudligi
  tekshirildi (butun paket bo'ylab).
- Tashqi kutubxonalar (telegram, pydantic, aiosqlite, docker va h.k.) uchun
  yengil stub-modullar yaratilib, **butun bot haqiqatan import qilindi va
  `bot.main.main()` xatosiz bajarildi** (barcha handlerlar muvaffaqiyatli
  ro'yxatdan o'tdi).

## Bilinishi kerak bo'lgan cheklov
Bu muhitda internet yo'qligi sababli **haqiqiy** `python-telegram-bot`,
`pydantic`, `bcrypt` va h.k. kutubxonalarini o'rnatib to'liq integratsion
test (yoki `pytest`) ishga tushirish imkoni bo'lmadi — tekshiruv yuqoridagi
statik tahlil + soxta (stub) kutubxonalar bilan bajarildi. Kod mantig'i va
barcha bog'lanishlar (importlar, metod nomlari, konstantalar) to'liq
tasdiqlangan, lekin **serverga joylashtirishdan oldin**
`docker compose up -d` bilan bir marta jonli sinab ko'rish tavsiya etiladi.

## Keyingi qadamlar (kelishilgan, hali yozilmagan)
- 4-bosqich: Ollama orqali erkin buyruq (agentic router)

---

# 3-BOSQICH: Kunlik hisobot + Threshold Alertlar

## Yangi fayllar
- `bot/services/scheduler_service.py` — `daily_report_job` (kunlik hisobot)
  va `alert_check_job` (cpu/ram/disk threshold + konteyner to'xtashi uchun
  alert) funksiyalari. `python-telegram-bot`ning ichki `JobQueue`si orqali
  ishlaydi — alohida APScheduler kutubxonasi shart emas.
- `bot/handlers/alerts.py` — `/alerts`, `/alert_set <metrika> <chegara>
  [daqiqa]`, `/report_now` buyruqlari.

## Database
- Yangi `alerts` jadvali (`metric`, `threshold`, `duration_minutes`,
  `enabled`, `last_triggered_at`, `above_since`).
- `Database`ga qo'shilgan metodlar: `get_alerts`, `get_alert`,
  `upsert_alert`, `ensure_default_alerts`, `set_alert_above_since`,
  `mark_alert_triggered`, `set_alert_enabled`.
- Default chegaralar: CPU/RAM/Disk — 90%, 5 daqiqa davomida ushlab
  turilsa alert yuboriladi (qisqa "spike"lar uchun spam bo'lmasligi uchun
  debounce mexanizmi).

## Konteyner monitoring
- Har bir tekshiruv siklida barcha Docker konteynerlar holati tekshiriladi;
  ilgari "running" bo'lgan konteyner to'xtasa — bir marta xabar beriladi
  (`settings` jadvalidagi `alert_container_down_state` kaliti orqali
  takroriy xabar berilishining oldi olinadi).

## main.py o'zgarishi
- `application.job_queue.run_daily(...)` — `ENABLE_DAILY_REPORT=true`
  bo'lsa, `DAILY_REPORT_HOUR`da (bot timezone bo'yicha) ishga tushadi.
- `application.job_queue.run_repeating(...)` — `ENABLE_ALERTS=true` bo'lsa,
  har `ALERT_CHECK_INTERVAL_SECONDS` soniyada ishga tushadi.
- Agar `job_queue` mavjud bo'lmasa (masalan `[job-queue]` extra
  o'rnatilmagan bo'lsa), bot baribir ishga tushadi, faqat ogohlantirish
  logga yoziladi — halokatli xato bo'lmaydi.

## requirements.txt
- `python-telegram-bot==20.7` → `python-telegram-bot[job-queue]==20.7`
  (JobQueue uchun shart).
- Ishlatilmagan `APScheduler==3.10.4` qatori olib tashlandi (job-queue
  extra o'zi APScheduler'ni ichkarida o'rnatadi).

## constants.py
- `DAILY_REPORT` xabar shabloniga Docker va oxirgi backup ma'lumotlari
  qo'shildi.
- Yangi xabarlar: `CONTAINER_DOWN_ALERT`, `NO_ALERTS`, `ALERT_LIST`,
  `ALERT_SET_CONFIRM`, `ALERT_SET_USAGE`, `REPORT_SENT`.
- HELP matniga `/alerts`, `/alert_set`, `/report_now` qo'shildi.

## Tekshiruv
- Barcha yangi/o'zgargan fayllar `py_compile` orqali sintaksis tekshiruvi
  o'tkazdi.
- `Emoji`/`Messages`/`ButtonText`, `db.<method>()`, `settings.<attr>`,
  `register_*_handlers` — barcha statik moslik tekshiruvlari qaytadan
  ishga tushirildi va toza natija berdi.
- Stub-kutubxonalar (shu jumladan `JobQueue` va to'g'ri
  await/async-with ikki xil ishlaydigan `aiosqlite.execute()`) yangilanib,
  `bot.main.main()` yana bir bor to'liq, xatosiz bajarildi.
- `daily_report_job`, `alert_check_job`, `/alerts`, `/alert_set`,
  `/report_now` funksiyalari soxta (fake) Update/Context obyektlari bilan
  **to'g'ridan-to'g'ri chaqirilib**, runtime xatolarsiz ishlashi tasdiqlandi.

## Bilinishi kerak bo'lgan cheklov (o'zgarmagan)
Bu muhitda internet yo'qligi sababli haqiqiy `python-telegram-bot[job-queue]`
kutubxonasini o'rnatib to'liq integratsion test qilib bo'lmadi — yuqoridagi
tekshiruvlar statik tahlil + soxta (stub) kutubxonalar bilan bajarildi.
Serverga joylashtirishdan oldin `docker compose up -d` bilan bir marta
jonli sinab ko'rish tavsiya etiladi, ayniqsa `/report_now` orqali kunlik
hisobot to'g'ri kelishini tekshiring.

## Keyingi qadam
- 4-bosqich: Ollama orqali erkin buyruq (agentic router) — hali yozilmagan.

---

# 4-BOSQICH: Ollama orqali erkin buyruq (Agentic Router)

## Yangi fayllar
- `bot/services/tool_registry.py` — markazlashgan `TOOLS` lug'ati: har bir
  yozuv `desc` (LLM uchun tavsif), `params`, `fn` (haqiqiy service
  chaqiruvi), `destructive` (bool). Yangi imkoniyat qo'shish uchun FAQAT
  shu faylga bitta yozuv qo'shish kifoya — boshqa hech narsa o'zgarmaydi.
  11 ta boshlang'ich vosita: `system_status`, `top_processes`,
  `docker_list`, `docker_restart`*, `docker_stop`*, `docker_start`,
  `docker_prune`*, `backup_create`, `vpn_status`, `reboot_server`*,
  `shutdown_server`* (* = destruktiv).
- `bot/services/agent_service.py` — `route_message(text)` xabarni
  Ollama'ga yuboradi (JSON-mode), qaysi vosita mos kelishini so'raydi;
  `execute_tool(name, params)` — tanlangan vositani ishga tushiradi.
- `bot/handlers/agent.py` — har qanday oddiy matn xabarini (buyruq
  bo'lmasa) `agent_service`ga yo'naltiradi. Destruktiv vosita aniqlansa,
  **hech qachon to'g'ridan-to'g'ri bajarilmaydi** — inline Ha/Yo'q
  tasdiqlash ko'rsatiladi (parametrlar `context.user_data` da vaqtincha
  saqlanadi), faqat tasdiqlangandan keyin bajariladi.

## Xavfsizlik dizayni
- Global auth gate (1-bosqich) barcha oddiy matnlardan ham OLDIN ishlaydi
  — demak agent faqat autentifikatsiyadan o'tgan sessiyalar uchun
  ishlaydi, parol so'ralayotgan xabar hech qachon agentga yetib bormaydi.
- Destruktiv vositalar statik `/reboot`, `/shutdown` buyruqlari kabi emas,
  balki alohida `agent_confirm:` callback namespace orqali tasdiqlanadi
  (chunki ularda dinamik parametrlar bor — masalan qaysi konteyner nomi),
  lekin bir xil UX (Ha/Yo'q tugmalari, `ButtonText.CONFIRM_GO/CANCEL`).
- Ollama noma'lum/ixtiro qilingan vosita nomini qaytarsa (`TOOLS`da
  yo'q), `tool_name = None` qilib e'tiborsiz qoldiriladi — LLM
  "gallyutsinatsiyasi" orqali ro'yxatdan tashqari funksiya chaqirilishi
  mumkin emas.

## Sozlamalar (`.env.example`, `bot/config.py`)
- `ENABLE_AGENT=true` — agentni butunlay o'chirish/yoqish (o'chirilsa,
  botga faqat `/` buyruqlari orqali murojaat qilinadi, Ollama'ga hech
  qanday oddiy matn yuborilmaydi).
- `AGENT_MODEL=` — bo'sh bo'lsa `OLLAMA_DEFAULT_MODEL` ishlatiladi.
  Tool-tanlash uchun umumiy instruction-following model (masalan
  llama3.1) coding-modeliga qaraganda ko'proq mos kelishi mumkin, shuning
  uchun alohida sozlanadi.

## bot/services/ollama_service.py
- `generate()` metodiga `json_mode: bool` va `system: Optional[str]`
  parametrlari qo'shildi — `json_mode=True` bo'lsa Ollama'ning
  `format: "json"` parametri orqali faqat valid JSON qaytarish so'raladi.

## bot/main.py
- `register_agent_handlers(application)` faqat `settings.enable_agent`
  bo'lsa chaqiriladi, va boshqa barcha handlerlardan KEYIN ro'yxatdan
  o'tkaziladi (chunki uning filtri `filters.TEXT & ~filters.COMMAND` —
  buyruqlarga hech qachon aralashmaydi, lekin har ehtimolga qarshi eng
  oxirida qoldirildi).

## requirements.txt
- Yangi tashqi bog'liqlik qo'shilmadi (`json` standart kutubxona,
  Ollama'ga so'rov mavjud `aiohttp` orqali ketadi).

## Tekshiruv (hammasi shu muhitda bajarildi)
- Barcha yangi/o'zgargan fayllar `py_compile` orqali sintaksis
  tekshiruvidan o'tdi.
- To'liq statik moslik tekshiruvlari (Emoji/Messages/ButtonText,
  `db.<method>()`, `settings.<attr>`, `register_*_handlers`, ichki
  `bot.*` importlar) qaytadan ishga tushirildi — barchasi toza.
- Stub-kutubxonalar bilan `bot.main.main()` **ikkala holatda ham**
  (`ENABLE_AGENT=true` va `ENABLE_AGENT=false`) xatosiz bajarildi.
- `agent_service.route_message()` **5 xil stsenariy** bilan sinaldi
  (to'g'ri vosita, destruktiv vosita+parametr, buzilgan JSON, mavjud
  bo'lmagan vosita nomi, haqiqiy `execute_tool` chaqiruvi) — barchasi
  kutilganidek ishladi.
- `agent_message_handler` va `agent_confirm_callback` **to'liq
  end-to-end** (matn kelishi → Ollama tanlovi → tasdiqlash so'ralishi →
  tasdiqlangandan keyin bajarilishi → bekor qilish yo'li) soxta
  Update/Context obyektlari bilan sinaldi — barcha yo'llar xatosiz
  ishladi (bitta joyda docker stub'ning cheklovi tufayli "Xatolik yuz
  berdi" ko'rindi, bu try/except orqali to'g'ri ushlanishi va foydalanuvchiga
  yumshoq xabar berilishini ko'rsatdi, dastur qulamadi).

## Bilinishi kerak bo'lgan cheklov
Bu muhitda internet yo'qligi sababli haqiqiy Ollama serveriga ulanib
sinab bo'lmadi — barcha testlar soxta (mock) `generate()` javoblari bilan
bajarildi. Real muhitda serverga joylashtirgandan so'ng:
1. Ollama modelini yuklab oling: `ollama pull llama3.1` (yoki
   `AGENT_MODEL`da ko'rsatgan model).
2. Botga oddiy matn bilan murojaat qiling ("konteynerlar holatini
   ko'rsat" kabi) va javobni tekshiring.
3. Agar model noto'g'ri JSON qaytarsa, bot buni graceful qabul qilib
   oddiy matn sifatida ko'rsatadi (xato bermaydi), lekin tool
   ishlamaydi — kerak bo'lsa `AGENT_MODEL`ni boshqa modelga almashtiring.

## Loyihaning hozirgi holati
1, 2, 3 va 4-bosqichlarning barchasi yozildi va shu muhitda mavjud
vositalar (statik tahlil + stub-kutubxonalar bilan to'liq import va
end-to-end funksional testlar) orqali tekshirildi. Serverga
joylashtirishdan oldin **bitta marta jonli muhitda sinab ko'rish**
tavsiya etiladi (`docker compose up -d`, keyin `/start`, parolni
kiritish, va asosiy buyruqlarni sinash).

---

# QO'SHIMCHA: Admin ID talabini olib tashlash + lockout 3 daqiqaga

## O'zgarish sababi
Foydalanuvchi so'rovi: "admin id kerak emas, uni o'rniga admin
paroldan foydalanamiz, har bir qurilma va akkauntdan kira olishim kerak,
xato parol uchun 5 tadan keyin 2-3 minutdan pauza qo'y".

## bot/config.py
- `telegram_superadmin_id`: `int` (majburiy) → `Optional[int]` (ixtiyoriy,
  default `None`). Bot ishga tushishi uchun endi FAQAT
  `TELEGRAM_BOT_TOKEN` va `BOT_PASSWORD_HASH` kerak — hech qanday
  Telegram ID talab qilinmaydi.
- `login_lockout_minutes` default qiymati `15` → `3` ga o'zgartirildi
  (`.env`da `LOGIN_LOCKOUT_MINUTES` orqali baribir sozlanadi).
  `max_login_attempts` allaqachon `5` edi — o'zgarmadi.

## bot/services/scheduler_service.py
- `_notify()` funksiyasi: agar `TELEGRAM_SUPERADMIN_ID` berilgan bo'lsa
  — faqat o'sha chatga; **berilmagan bo'lsa (yangi default) — barcha
  faol sessiyalarga** (`db.get_all_sessions(active_only=True)` orqali)
  broadcast qiladi. Bu botning "sobit admin yo'q, faqat umumiy parol"
  modeliga to'liq mos keladi — kim kirgan bo'lsa, kunlik hisobot/alert
  o'shanga yuboriladi.

## .env.example, README.md, docs/INSTALL.md, scripts/install.sh
- `TELEGRAM_SUPERADMIN_ID` endi bo'sh qoldiriladigan (ixtiyoriy) sifatida
  hujjatlashtirildi, barcha izohlar yangilandi.
- `scripts/install.sh`: admin ID so'rovi endi ixtiyoriy (Enter bosib
  o'tkazib yuborish mumkin). Aksincha, **parol so'rovi endi majburiy**
  qilib qo'yildi (bo'sh parol qabul qilinmaydi, loop orqali qayta
  so'raladi) — chunki parol botga kirishning YAGONA yo'li bo'lib qoldi.

## Tekshiruv (real SQLite bilan, mock emas)
Oldingi bosqichlarda ishlatilgan aiosqlite stub butunlay soxta edi
(hech narsa saqlamas edi). Bu safar **stdlib `sqlite3`ga asoslangan,
haqiqatan ma'lumot saqlaydigan stub** yozildi va quyidagilar **haqiqiy
SQL so'rovlar bilan** sinaldi:
- `TELEGRAM_SUPERADMIN_ID` berilmaganda: sessiya yo'qligida
  bildirishnoma yuborilmasligi; 2 ta turli akkaunt sessiyasi ochilganda
  ikkalasiga ham xabar borishi.
- Login lockout: 4 xato urinishdan keyin hali bloklanmasligi, 5-xato
  urinishdan keyin bloklanishi, va bu bloklanish **faqat o'sha
  `telegram_id`ga tegishli** ekanligi (boshqa akkaunt ta'sirlanmasligi).
- `bot.main.main()` — `TELEGRAM_SUPERADMIN_ID` muhit o'zgaruvchisi
  umuman o'rnatilmagan holatda ham xatosiz to'liq ishga tushishi.

## Bilinishi kerak bo'lgan cheklov
Bu muhitda internet yo'qligi sababli haqiqiy `bcrypt`/`python-telegram-bot`
kutubxonalarini o'rnatib bo'lmadi — yuqoridagi testlar stdlib `sqlite3`ga
asoslangan haqiqiy DB stub va soxta bcrypt/telegram obyektlari bilan
bajarildi. SQL mantig'i va lockout hisob-kitobi haqiqiy ma'lumotlar bazasi
ustida tasdiqlangan, ammo real `bcrypt` hash tekshiruvi sinalmadi (u
oddiy funksiya bo'lgani uchun xavf past, lekin serverga qo'yishdan oldin
`python -m scripts.gen_password_hash` va keyin botga kirishni bir marta
qo'lda sinab ko'rish tavsiya etiladi).
