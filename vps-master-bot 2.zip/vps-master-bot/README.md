# 🖥 VPS Master Bot

[![CI](https://github.com/1jehuang/vps-master-bot/actions/workflows/ci.yml/badge.svg)](https://github.com/1jehuang/vps-master-bot/actions/workflows/ci.yml)
[![Docker](https://github.com/1jehuang/vps-master-bot/actions/workflows/docker-build.yml/badge.svg)](https://github.com/1jehuang/vps-master-bot/actions/workflows/docker-build.yml)
[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

**O'zbek tilida self-hosted VPS boshqaruv boti.**

Bitta Telegram bot orqali serveringizni to'liq boshqaring: AI kod yozish, Docker, monitoring, fayllar, VPN, media server, Git, zaxira, Nginx, ma'lumotlar bazasi va loglar.

## 🚀 Tez o'rnatish

```bash
curl -fsSL https://raw.githubusercontent.com/1jehuang/vps-master-bot/main/scripts/install.sh | sudo bash
```

## 📋 Xususiyatlar

| Modul | Tavsif | Status |
|-------|--------|--------|
| 🤖 AI Kod | Ollama orqali lokal AI bilan kod yozish | ✅ Tayyor |
| 🐳 Docker | Konteiner va Compose boshqaruvi | ✅ Tayyor |
| 📊 Monitoring | Real-time CPU, RAM, Disk, Tarmoq | ✅ Tayyor |
| 📁 Fayllar | Fayl menejeri va qidirish | ✅ Tayyor |
| 🔒 VPN | WireGuard peer boshqaruvi | ✅ Tayyor |
| 🎬 Media | Jellyfin media server | ✅ Tayyor |
| 📦 Git | Gitea repositoriya boshqaruvi | ✅ Tayyor |
| 💾 Zaxira | Avtomatik zaxira va tiklash | ✅ Tayyor |
| ⚙️ Tizim | Reboot, xizmatlar, yangilash | ✅ Tayyor |
| 🌐 Nginx | Sayt va SSL boshqaruvi | ✅ Tayyor |
| 🗄 MB | PostgreSQL, MySQL, Redis | ✅ Tayyor |
| 📋 Loglar | Tizim va xizmat loglari | ✅ Tayyor |

## 🛠 Texnologiyalar

- **Python 3.11+** - Asosiy til
- **python-telegram-bot 20+** - Telegram API
- **Pydantic v2** - Ma'lumotlar validatsiyasi
- **SQLite (aiosqlite)** - Ma'lumotlar bazasi
- **Docker SDK** - Konteiner boshqaruvi
- **psutil** - Tizim monitoringi
- **Ollama** - Lokal AI model

## ⚙️ Sozlamalar

`.env` faylini tahrirlang:

```env
TELEGRAM_BOT_TOKEN=your_token
TELEGRAM_SUPERADMIN_ID=          # ixtiyoriy - bo'sh qoldirsa bo'ladi
BOT_PASSWORD_HASH=          # python -m scripts.gen_password_hash orqali yarating
OLLAMA_HOST=http://localhost:11434
```

## 🐳 Docker bilan ishga tushirish

```bash
# Faqat bot
docker compose up -d

# Bot + Ollama AI
docker compose --profile ai up -d
```

## 🛡️ Xavfsizlik

- ✅ Parol asosida kirish - istalgan Telegram akkaunt/qurilmadan bitta umumiy parol bilan (owner-only)
- ✅ Sessiya boshqaruvi - `/sessions`, `/logout`, `/change_password`
- ✅ Ortiqcha noto'g'ri urinishlardan keyin vaqtinchalik bloklash (lockout)
- ✅ Har bir buyruq logga yoziladi
- ✅ Xavfli buyruqlarni bloklash
- ✅ Rate limiting
- ✅ Path traversal himoyasi
- ✅ Command injection himoyasi

## 📁 Loyiha tuzilishi

```
vps-master-bot/
├── bot/                    # Asosiy ilova kodi
│   ├── handlers/           # 12 ta Telegram handler
│   ├── services/           # 8 ta tashqi xizmat
│   ├── middlewares/        # Auth, Logging, Rate Limit
│   ├── keyboards/          # Inline klaviaturalar
│   ├── models/             # Pydantic modellar
│   └── utils/              # Yordamchi funksiyalar
├── docker/                 # Docker konfiguratsiyasi
├── scripts/                # O'rnatish skriptlari
├── tests/                  # Pytest testlari
└── docs/                   # Hujjatlar
```

## 🤝 Hissa qo'shish

1. Fork qiling
2. Branch yarating (`git checkout -b feature/yangi-funksiya`)
3. O'zgarishlarni commit qiling (`git commit -m 'Yangi funksiya qo'shildi'`)
4. Push qiling (`git push origin feature/yangi-funksiya`)
5. Pull Request oching

## 📜 Litsenziya

MIT Litsenziya - to'liq matn uchun [LICENSE](LICENSE) faylini ko'ring.

## 🙏 Minnatdorchilik

- [python-telegram-bot](https://github.com/python-telegram-bot/python-telegram-bot)
- [Ollama](https://ollama.com)
- [jcode](https://github.com/1jehuang/jcode)
