"""Inline keyboard layouts."""
from __future__ import annotations

from .inline import (
    get_main_menu_keyboard,
    get_back_keyboard,
    get_pagination_keyboard,
    get_docker_menu_keyboard,
    get_monitoring_menu_keyboard,
    get_backup_menu_keyboard,
    get_system_menu_keyboard,
    get_nginx_menu_keyboard,
    get_db_menu_keyboard,
    get_logs_menu_keyboard,
    get_ai_menu_keyboard,
    get_vpn_menu_keyboard,
    get_media_menu_keyboard,
    get_git_menu_keyboard,
)

__all__ = [
    "get_main_menu_keyboard",
    "get_back_keyboard",
    "get_pagination_keyboard",
    "get_docker_menu_keyboard",
    "get_monitoring_menu_keyboard",
    "get_backup_menu_keyboard",
    "get_system_menu_keyboard",
    "get_nginx_menu_keyboard",
    "get_db_menu_keyboard",
    "get_logs_menu_keyboard",
    "get_ai_menu_keyboard",
    "get_vpn_menu_keyboard",
    "get_media_menu_keyboard",
    "get_git_menu_keyboard",
]
