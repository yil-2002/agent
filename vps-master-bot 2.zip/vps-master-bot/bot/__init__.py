"""VPS Master Bot - Self-hosted VPS management via Telegram."""
